function oldFun(){
    console.log("Extra");
    console.log("Do");
}
console.log("start");

oldFun();