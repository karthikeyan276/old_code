            var s1 = 1;
            var s2 = 18;
            var s3 = (!(s1&&s2))
            console.log(s3);